<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpstudy\PHPTutorial\WWW\pro\public/../application/index\view\display\index.html";i:1549004909;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>闲言碎语</title>
	<link href="/pro/__STATIC__/css/home.css" rel="stylesheet"/>
</head>
<body>

	<div class="container">	
	<div id='wall'>
	<ul>
		 <?php if(is_array($data) || $data instanceof \think\Collection): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?> 
		<li>
			<a href="">
				<h2 ><?php echo $vo['content']; ?></h2>				
			</a>
		</li>
		 <?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
</div>
<?php echo $data->render(); ?>
	</div>
</body>
</html>