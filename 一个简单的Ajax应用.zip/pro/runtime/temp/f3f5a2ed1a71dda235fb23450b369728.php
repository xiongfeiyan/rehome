<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpstudy\PHPTutorial\WWW\pro\public/../application/index\view\index\index.html";i:1548999633;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>闲言碎语</title>
	<link href="/pro__STATIC__/css/dis.css" rel="stylesheet"/>
	<script src="https://cdn.bootcss.com/jquery/1.10.2/jquery.min.js"></script> 
	<script src="/pro__STATIC__/js/vue.min.js"></script>
	<script type="text/javascript" src="/pro__STATIC__/js/alert.js"></script>
	<script type="text/javascript" src="/pro__STATIC__/js/jquery-1.11.0.min.js"></script>
</head>
<script type="text/javascript">
	function reset(){
		document.getElementById("content").value="";
	}
	function display_alert()
	  {     
	  	var content=document.getElementById("content").value;
	  	if(!document.getElementById("content").value){
	  		Alert.showMsg("Please input some words!");
	  	}else{
	  		//alert(content);
	 		  $.ajax({
	 		  	url: "<?php echo url('Index/add'); ?>",
	 		  	data: {content:content},
	 		  	type: "POST",
	 		  	dataType: "TEXT",	 		  	
	   			success: function(data){
	   				if(data=="ok"){
	   					Alert.showMsg("Success!");
	   				}else{
	   					Alert.showMsg("False!");
	   				}
		        	}
		  	})
	  	}
	  }
</script>

<body>
		<div class="container">
				<div class="con">	
					<h1>I Found......</h1>
					<div class="nice-submit">					
						<textarea name="content" id="content" cols="30" rows="10" class="xx"></textarea>
					</div>
					<div class="nice-submit">
						<input type="submit" value="send it" class="ww"  id="sub" name="sub" onclick="display_alert()">
						<button  class="reset" onclick="reset()">reset</button>
					</div>

				</div>				
			<div>
				<a href="<?php echo url('Display/index'); ?>"><button  class="enter">have a look</button></a>
			</div>
		</div>
</body>
</html>
