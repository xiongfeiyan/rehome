<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"D:\phpstudy\PHPTutorial\WWW\sm\public/../application/index\view\index\index.html";i:1548762153;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>简医</title>
	<link href="/sm/__STATIC__/css/home.css" rel="stylesheet"/>
</head>
<body>
	<div class="container">	
		<div class="side">			
			<ul class="ul-side">
			  <li class="li-side"><a href="#home">主页</a></li>
			  <li  class="li-side"><a href="#news">新闻</a></li>
			  <li class="li-side"><a href="#contact">联系</a></li>
			  <li class="li-side"><a href="#about">关于</a></li>
			   <li class="li-side"><a href="#home">主页</a></li>
			  <li class="li-side"><a href="#news">新闻</a></li>
			</ul>
		</div>	
		<div class="body">
			<div class="mod1">
				<div class="menu">
				<div class="content">
					<ul class="ul-menu"><a href="#">登录</a></ul>
					<ul class="ul-menu"><a href="#">注册</a></ul>
				</div>
				 <div class="border"></div>
				  </div>
				<div class="page1">
					<div class="exten">
						<div class="forum-demo"></div>
						<div class="menses-demo"></div>
					</div>
					<div class="man">
						<img src="/sm/public/static/images/2.png" width="324" height="600" usemap="#Map" alt="" id="img1">
                      <map name="Map">                
                        <area shape="circle" coords="185,34,25" href="https://www.baidu.com" alt="forum">
                        <area shape="circle" coords="169,213,25" href="https://www.baidu.com" alt="menses">
                      </map>
				  </div>
				</div>
			</div>
			<div class="mod2">
				<div class="mv"></div>
				<div class="bar">
					<div class="b1"></div>
					<div class="b1"></div>
					<div class="b1"></div>
					<div class="b1"></div>
					<div class="b1"></div>
					<div class="b1"></div>
				</div>
			</div>
			<div class="mod3"></div>
		</div>
		
	</div>
</body>
<script>
	imgobj=document.getElementById('img1');
	imgobj.onmouseenter=function(){
		this.src='/sm/public/static/images/1.png';
	};
	imgobj.onmouseout=function(){
		this.src='/sm/public/static/images/3.png';
	};
</script>
</html>