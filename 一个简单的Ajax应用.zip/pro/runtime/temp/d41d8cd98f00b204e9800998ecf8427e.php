<?php if (!defined('THINK_PATH')) exit(); /*a:0:{}*/ ?>
