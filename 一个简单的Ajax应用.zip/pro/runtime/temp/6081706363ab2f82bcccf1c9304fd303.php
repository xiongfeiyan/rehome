<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"D:\phpstudy\PHPTutorial\WWW\pro\public/../application/index\view\display\display.html";i:1548837433;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>zs</title>
	<link href="/pro/__STATIC__/css/home.css" rel="stylesheet"/>
</head>
<body>
	<div class="container">	
	<div id='wall'>
	<ul>
		<li>
			<a href="">
				<h2>周一：</h2>
				
			</a>
		</li>
	</ul>
</div>
	</div>
</body>
</html>