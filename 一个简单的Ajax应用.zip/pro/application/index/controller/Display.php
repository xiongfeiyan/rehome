<?php
namespace app\index\controller;
use think\Controller;
use think\Model;
use think\Db;

class Display extends Controller
{
    public function index()
    {
    	$count=Db::table('info')->count();
       $data=Db::table('info')->order('id desc')->paginate(8,$count/8+1);
    	$this->assign('data',$data);
		// 渲染模板输出
		//return $this->fetch('list');
    	return view();
    }
    public function read(){
       }
}
