<?php
namespace app\index\controller;
use think\Controller;
use think\Model;
use think\Db;

class Index extends Controller
{
    public function index()
    {
        return view();
    }
     public function add()
    {
       $data['content']=$_POST['content'];
       //print($content);
      $result= Db::table('info')->insert($data);
      if ($result) {
      //	$this->success("success");
      echo "ok";
      } else {
      //	$this->error("false");
    	echo "no";
      }
      
    }
}
